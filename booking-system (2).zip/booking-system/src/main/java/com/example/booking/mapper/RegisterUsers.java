package com.example.booking.mapper;

import com.example.booking.dto.auth.RegisterResponse;
import com.example.booking.dto.resource.ResourceResponse;
import com.example.booking.entity.Register;
import com.example.booking.entity.Resource;

public class RegisterUsers {

	private RegisterUsers(){} 
	
	public static RegisterResponse toResponse(Register r){
		return new RegisterResponse(r.getId(),r.getName(),r.getAddress(),r.getDob(),r.getPassword());
		
	}
}
