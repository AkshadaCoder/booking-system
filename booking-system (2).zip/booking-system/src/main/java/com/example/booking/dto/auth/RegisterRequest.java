package com.example.booking.dto.auth;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
public record RegisterRequest(@NotBlank String username,@NotBlank String password,@NotBlank String address,@NotBlank String birthdate) {}
