package com.example.booking.dto.auth;

public record RegisterResponse(Long id,String name,String address,String dob,String password ) {

	
}
