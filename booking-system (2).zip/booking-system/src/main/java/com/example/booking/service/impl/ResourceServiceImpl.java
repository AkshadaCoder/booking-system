package com.example.booking.service.impl;
import com.example.booking.dto.resource.*;
import com.example.booking.entity.Resource; 
import com.example.booking.exception.ResourceNotFoundException; 
import com.example.booking.mapper.ResourceMapper; 
import com.example.booking.repository.ResourceRepository; 
import com.example.booking.service.ResourceService; 
import lombok.RequiredArgsConstructor; 
import org.springframework.data.domain.*; 
import org.springframework.stereotype.Service; 
import org.springframework.transaction.annotation.Transactional;

@Service 
@RequiredArgsConstructor 
public class ResourceServiceImpl implements ResourceService 
{ 
	private final ResourceRepository repo; 
	@Transactional 
	public ResourceResponse create(ResourceCreateRequest r){
		return ResourceMapper.toResponse(repo.save(Resource.builder().name(r.name()).description(r.description()).type(r.type()).price(r.price()).available(r.available()).build()));
		
	}
	public Page<ResourceResponse> list(Pageable p)
	{
		return repo.findAll(p).map(ResourceMapper::toResponse);
		
	} 
	
	public ResourceResponse get(Long id){
		return ResourceMapper.toResponse(repo.findById(id).orElseThrow(()->new ResourceNotFoundException("Resource not found: "+id)));
		
	} 
	
	@Transactional 
	public ResourceResponse update(Long id,ResourceUpdateRequest r){
		Resource x=repo.findById(id).orElseThrow(()->new ResourceNotFoundException("Resource not found: "+id));
		x.setName(r.name());x.setDescription(r.description());x.setType(r.type());
		x.setPrice(r.price());
		x.setAvailable(r.available());
		return ResourceMapper.toResponse(repo.save(x));
	
	}
	
	@Transactional 
	public void delete(Long id){
		if(!repo.existsById(id))throw new ResourceNotFoundException("Resource not found: "+id);
		repo.deleteById(id);
		} 
}
