package com.example.booking.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

@Entity
public class Register 
{
	 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
	 @Column(nullable=false,length=120) private String name;
	 @Column(nullable=false,length=130) private String password;
	 @Column private String dob;
	 @Column private String address;
	 public Register() {
		super();
		// TODO Auto-generated constructor stub
	 }
	 public Long getId() {
		 return id;
	 }
	 public void setId(Long id) {
		 this.id = id;
	 }
	 public String getName() {
		 return name;
	 }
	 public void setName(String name) {
		 this.name = name;
	 }
	 public String getPassword() {
		 return password;
	 }
	 public void setPassword(String password) {
		 this.password = password;
	 }
	 public String getDob() {
		 return dob;
	 }
	 public void setDob(String dob) {
		 this.dob = dob;
	 }
	 public String getAddress() {
		 return address;
	 }
	 public void setAddress(String address) {
		 this.address = address;
	 }
	
	
	 
	

}
