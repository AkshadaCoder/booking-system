package com.example.booking.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class RegisterController 
{
	

}
